package com.example.weatherapp_lab1

data class WeatherDescription(
    val id: Int,
    val main: String,
    val description: String,
    val icon: String
)