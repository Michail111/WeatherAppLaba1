package com.example.weatherapp_lab1

data class Main(
    val temp: Double,
    val pressure: Int,
    val humidity: Int
)