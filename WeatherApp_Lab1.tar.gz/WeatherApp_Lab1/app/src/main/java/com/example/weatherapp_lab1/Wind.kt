package com.example.weatherapp_lab1

data class Wind(
    val speed: Double,
    val deg: Int
)