package com.example.weatherapp_lab1

data class Clouds(
    val all: Int
)